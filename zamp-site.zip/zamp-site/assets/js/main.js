/* ===========================================================
   ZAMP — interactions
   =========================================================== */
(function () {
  'use strict';

  /* ---------- nav scrolled state ---------- */
  var nav = document.querySelector('.nav');
  var onScroll = function () {
    if (window.scrollY > 8) nav.classList.add('scrolled');
    else nav.classList.remove('scrolled');
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- scroll reveal ---------- */
  var reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    var ro = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          var el = e.target;
          var delay = el.getAttribute('data-delay') || 0;
          setTimeout(function () { el.classList.add('in'); }, delay);
          ro.unobserve(el);
        }
      });
    }, { threshold: 0.14 });
    reveals.forEach(function (el) { ro.observe(el); });
  } else {
    reveals.forEach(function (el) { el.classList.add('in'); });
  }

  /* ===========================================================
     INTERACTIVE DEMO — "Watch Zamp clear an invoice exception"
     =========================================================== */
  var demo = document.getElementById('demo');
  if (demo) {
    var STEPS = [
      {
        n: '01', title: 'Invoice lands', status: 'flagged',
        desc: 'Invoice #INV-4471 from Apex Logistics arrives. Zamp matches it to the PO and flags a mismatch — billed amount exceeds the purchase order by $1,240.',
        sys: 'SOURCE · inbox + ERP', dur: 2200, type: 'auto'
      },
      {
        n: '02', title: 'Investigates', status: 'working',
        desc: 'Reads PO-2208, the goods-receipt note, and 14 prior invoices from this vendor across three systems. Finds a partial earlier delivery that justifies the higher amount.',
        sys: 'READING · ERP · GRN · vendor history', dur: 3000, type: 'auto'
      },
      {
        n: '03', title: 'Drafts the fix', status: 'working',
        desc: 'Proposes a 3-way-match override, codes it to Freight-In, and writes a confirmation note to the vendor. Shows its reasoning. Confidence 96%.',
        sys: 'DRAFTED · awaiting sign-off', dur: 2600, type: 'auto'
      },
      {
        n: '◆', title: 'Priya approves', status: 'await',
        desc: 'One judgment call: approve the override. This is the only human touch in the entire flow.',
        sys: 'WAITING FOR HUMAN', dur: 0, type: 'human'
      },
      {
        n: '05', title: 'Closes the loop', status: 'done',
        desc: 'Posts to the ERP, emails the vendor, and logs a full audit trail. Saves the pattern so this vendor never flags for the same reason again.',
        sys: 'DONE · 0 further touches', dur: 2200, type: 'auto'
      }
    ];

    var logItems = demo.querySelectorAll('.log-item');
    var bar = demo.querySelector('.progress-bar');
    var statusEl = demo.querySelector('.status');
    var flagEl = demo.querySelector('.inv-flag');
    var poRow = demo.querySelector('[data-po]');
    var humanWrap = demo.querySelector('.human-action');
    var replayBtn = demo.querySelector('.replay');
    var tally = demo.querySelector('.demo-tally');
    var timers = [];
    var started = false;

    function clearTimers() { timers.forEach(clearTimeout); timers = []; }

    function setStatus(s) {
      statusEl.className = 'status ' + s;
      statusEl.textContent =
        s === 'flagged' ? 'Exception' :
        s === 'working' ? 'Working' :
        s === 'await' ? 'Needs you' : 'Resolved';
    }

    function renderStep(i, partial) {
      // partial=true means "in progress" (spinner); false means completed
      logItems.forEach(function (li, idx) {
        li.classList.remove('active', 'done', 'human');
        if (idx < i) li.classList.add('done');
      });
      var cur = logItems[i];
      if (!cur) return;
      cur.classList.add('active');
      if (STEPS[i].type === 'human') cur.classList.add('human');
      setStatus(STEPS[i].status);

      // spinner on the active line while auto-working
      var sEl = cur.querySelector('.log-body .s');
      var base = STEPS[i].title;
      if (partial && STEPS[i].type === 'auto') {
        sEl.innerHTML = base + '<span class="spinner"></span>';
      } else {
        sEl.textContent = base;
      }
    }

    function go(i) {
      if (i >= STEPS.length) { finish(); return; }
      bar.style.width = ((i) / (STEPS.length - 1) * 100) + '%';

      if (STEPS[i].type === 'human') {
        renderStep(i, false);
        humanWrap.classList.add('show');
        tally.innerHTML = 'A human would spend <b>~22 min</b> here. With Zamp: <b>1 click.</b>';
        return; // wait for click
      }

      renderStep(i, true); // show spinner
      var t = setTimeout(function () {
        renderStep(i, false); // mark complete (no spinner)
        logItems[i].classList.add('done');
        logItems[i].classList.remove('active');
        // side effects per step
        if (i === 1) { flagEl.textContent = '⊙ Investigating across ERP, goods-receipt note, and vendor history…'; }
        var t2 = setTimeout(function () { go(i + 1); }, 320);
        timers.push(t2);
      }, STEPS[i].dur);
      timers.push(t);
    }

    function approve() {
      humanWrap.classList.remove('show');
      var i = 3;
      logItems[i].classList.add('done'); logItems[i].classList.remove('active', 'human');
      go(4);
    }

    function finish() {
      bar.style.width = '100%';
      setStatus('done');
      logItems[4].classList.add('done'); logItems[4].classList.remove('active');
      poRow.querySelector('.v').className = 'v fixed';
      poRow.querySelector('.v').textContent = '✓ matched';
      flagEl.classList.add('resolved');
      flagEl.textContent = '✓ Resolved end-to-end. Posted, vendor notified, audit trail logged — 1 human click total.';
      tally.innerHTML = 'Cleared end-to-end. Human touches: <b>1</b>. Time you got back: <b>~22 min</b>, on one invoice.';
    }

    function reset() {
      clearTimers();
      humanWrap.classList.remove('show');
      bar.style.width = '0%';
      logItems.forEach(function (li) {
        li.classList.remove('active', 'done', 'human');
        var s = li.querySelector('.log-body .s');
        s.textContent = s.getAttribute('data-base');
      });
      setStatus('flagged');
      poRow.querySelector('.v').className = 'v bad';
      poRow.querySelector('.v').textContent = '✕ +$1,240';
      flagEl.classList.remove('resolved');
      flagEl.textContent = '⚠ Billed amount is $1,240 over PO-2208. Would normally trigger a 6-day email chase.';
      tally.innerHTML = 'Press play in your head — this runs on its own.';
    }

    function start() {
      reset();
      var t = setTimeout(function () { go(0); }, 500);
      timers.push(t);
    }

    // store base titles
    logItems.forEach(function (li) {
      var s = li.querySelector('.log-body .s');
      s.setAttribute('data-base', s.textContent);
    });

    demo.querySelector('.approve-btn').addEventListener('click', approve);
    replayBtn.addEventListener('click', start);

    // autostart when in view (once)
    if ('IntersectionObserver' in window) {
      var dObs = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) {
          if (e.isIntersecting && !started) { started = true; start(); }
        });
      }, { threshold: 0.3 });
      dObs.observe(demo);
    } else { start(); }
  }

  /* ===========================================================
     IMPACT CALCULATOR
     =========================================================== */
  var calc = document.getElementById('calc');
  if (calc) {
    var MIN_PER_EXC = 12;      // mins a human spends per exception
    var FTE_HOURS = 1800;      // productive hours / FTE / yr

    var inv = calc.querySelector('#inp-invoices');
    var exc = calc.querySelector('#inp-exceptions');
    var cost = calc.querySelector('#inp-cost');

    var invVal = calc.querySelector('#val-invoices');
    var excVal = calc.querySelector('#val-exceptions');
    var costVal = calc.querySelector('#val-cost');

    var headline = calc.querySelector('#calc-headline');
    var sub = calc.querySelector('#calc-sub');
    var rDollars = calc.querySelector('#r-dollars');
    var rHours = calc.querySelector('#r-hours');
    var rExc = calc.querySelector('#r-exc');
    var copyBtn = calc.querySelector('#copy-btn');
    var copyState = calc.querySelector('#copy-state');

    function commas(n) { return Math.round(n).toLocaleString('en-US'); }
    function money(n) {
      if (n >= 1e6) return '$' + (n / 1e6).toFixed(n >= 1e7 ? 0 : 1) + 'M';
      if (n >= 1e3) return '$' + Math.round(n / 1e3) + 'k';
      return '$' + commas(n);
    }

    function compute() {
      var invoices = +inv.value;
      var pct = +exc.value;
      var c = +cost.value;

      var excMonth = invoices * pct / 100;
      var excYear = excMonth * 12;
      var dollars = excYear * c;
      var hours = excYear * MIN_PER_EXC / 60;
      var fte = Math.max(1, Math.round(hours / FTE_HOURS));

      invVal.textContent = commas(invoices) + ' / mo';
      excVal.textContent = pct + '%';
      costVal.textContent = '$' + c;

      headline.innerHTML = '\u2248 the ' + fte + ' hire' + (fte > 1 ? 's' : '') + '<br>you won\u2019t make';
      sub.innerHTML = 'Clearing <b style="color:#fff">' + commas(excYear) + '</b> exceptions a year by hand is roughly ' + fte + ' full-time ' + (fte > 1 ? 'people' : 'person') + '. Zamp absorbs it — your team keeps the judgment.';

      rDollars.textContent = money(dollars) + '/yr';
      rHours.textContent = '~' + commas(hours) + ' hrs/yr';
      rExc.textContent = commas(excYear) + '/yr';

      calc._summary = 'Zamp — illustrative impact\n'
        + '• ' + commas(invoices) + ' invoices/month, ' + pct + '% exceptions ($' + c + ' to clear each)\n'
        + '• Exceptions cleared autonomously: ' + commas(excYear) + '/yr\n'
        + '• Exception-handling cost removed: ' + money(dollars) + '/yr\n'
        + '• Team hours returned: ~' + commas(hours) + '/yr (\u2248 ' + fte + ' FTE)\n'
        + 'Priced like a hire, not a tool — funded by the headcount or BPO you don\u2019t add.';
    }

    [inv, exc, cost].forEach(function (el) {
      el.addEventListener('input', compute);
    });
    compute();

    copyBtn.addEventListener('click', function () {
      var text = calc._summary || '';
      var done = function () {
        copyState.classList.add('show');
        setTimeout(function () { copyState.classList.remove('show'); }, 2200);
      };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(done, done);
      } else {
        var ta = document.createElement('textarea');
        ta.value = text; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); } catch (e) {}
        document.body.removeChild(ta); done();
      }
    });
  }

  /* ---------- footer year ---------- */
  var y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();
})();
